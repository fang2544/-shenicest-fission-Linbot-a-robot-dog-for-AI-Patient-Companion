# Third-party notices

## VITA Dynamics `vbot_ros2_msgs`

- Upstream: <https://github.com/VitaDynamics/vbot_ros2_msgs>
- Verified upstream commit: `a598337a7c4ec6a13cfe28ec6a8adf6866278a3c`
- License: Apache License 2.0
- Local path: `vbot_ws/src/vbot_ros2_msgs`

The local directory was compared file-for-file with the commit above (excluding GitHub workflow and repository metadata). It is an upstream-generated ROS 2 interface snapshot used to compile and test this secondary-development workspace. Its interface definitions remain governed by the upstream copyright and license. Do not present the five application packages as official VITA Dynamics products.

Before a release, record the exact upstream commit used:

```bash
git -C /path/to/upstream/vbot_ros2_msgs rev-parse HEAD
```

Then add that commit ID to the release notes so hardware compatibility can be reproduced.
