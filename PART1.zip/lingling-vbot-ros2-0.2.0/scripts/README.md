# 脚本目录

| 目录 | 内容 |
| --- | --- |
| `build/` | 构建 ROS 2 工作空间 |
| `launch/` | 启动 Gazebo、RViz2 和浏览器可视化 |
| `acceptance/` | 运行仿真与业务验收 |
| `test/` | 运行 ROS 通信链路集成测试 |
| `quality/` | 检查源码语法、版本和仓库垃圾文件 |
| `release/` | 生成统一源码包和五个独立功能包 |

所有宿主机脚本均可从仓库根目录直接执行，例如：

```bash
./scripts/quality/check_repository_clean.sh
./scripts/acceptance/运行VBot仿真.sh
./scripts/launch/启动VBot图形仿真.sh
./scripts/release/create_release_archive.sh 0.2.0
```
