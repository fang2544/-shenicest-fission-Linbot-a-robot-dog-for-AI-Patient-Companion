#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
version="${1:-0.2.0}"
release_name="lingling-vbot-ros2-${version}"
dist_dir="${repo_root}/dist"
feature_dist_dir="${dist_dir}/feature-packages"
staging_root="$(mktemp -d)"
release_tar="${dist_dir}/${release_name}.tar.gz"
release_zip="${dist_dir}/${release_name}.zip"

cleanup() {
  rm -rf "${staging_root}"
}
trap cleanup EXIT

"${repo_root}/scripts/quality/check_repository_clean.sh"
mkdir -p "${dist_dir}" "${feature_dist_dir}" "${staging_root}/${release_name}"

# 删除同版本旧产物，避免 zip 更新模式保留已经移除的文件。
for old_artifact in "${release_tar}" "${release_zip}" "${dist_dir}/SHA256SUMS"; do
  if [[ -f "${old_artifact}" ]]; then
    find "${old_artifact}" -delete
  fi
done

COPYFILE_DISABLE=1 tar -C "${repo_root}" -cf - \
  --exclude='./.git' \
  --exclude='./dist' \
  --exclude='./Docker-Desktop-*.dmg' \
  --exclude='./vbot_ws/build*' \
  --exclude='./vbot_ws/install*' \
  --exclude='./vbot_ws/log*' \
  --exclude='./vbot_ws/maps/*' \
  --exclude='./vbot_ws/reports/*' \
  --exclude='./vbot_ws/packages/*' \
  --exclude='./vbot_ws/src/*.zip' \
  --exclude='__pycache__' \
  --exclude='*.py[co]' \
  --exclude='__MACOSX' \
  --exclude='._*' \
  --exclude='.DS_Store' \
  . | tar -C "${staging_root}/${release_name}" -xf -

COPYFILE_DISABLE=1 tar -C "${staging_root}" -czf \
  "${release_tar}" "${release_name}"

(cd "${staging_root}" && zip -X -q -r \
  "${release_zip}" "${release_name}")

packages=(
  wakeup_welcome
  lost_pause_reminder
  hospital_escort_mvp
  aed_emergency_response
  restroom_priority_assistance
)

for package in "${packages[@]}"; do
  package_archive="${feature_dist_dir}/${package}-${version}.zip"
  if [[ -f "${package_archive}" ]]; then
    find "${package_archive}" -delete
  fi
  (cd "${repo_root}/vbot_ws/src" && COPYFILE_DISABLE=1 zip -X -q -r \
    "${package_archive}" "${package}" \
    -x '*/__pycache__/*' '*.py[co]' '*/__MACOSX/*' '*/._*' '*/.DS_Store')
  echo "已生成 ${package_archive}"
done

(
  cd "${dist_dir}"
  artifacts=(
    "feature-packages/aed_emergency_response-${version}.zip"
    "feature-packages/hospital_escort_mvp-${version}.zip"
    "feature-packages/lost_pause_reminder-${version}.zip"
    "feature-packages/restroom_priority_assistance-${version}.zip"
    "feature-packages/wakeup_welcome-${version}.zip"
    "${release_name}.tar.gz"
    "${release_name}.zip"
  )
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "${artifacts[@]}" > SHA256SUMS
  else
    shasum -a 256 "${artifacts[@]}" > SHA256SUMS
  fi
)

echo "已生成 ${release_tar}"
echo "已生成 ${release_zip}"
echo "已生成 ${dist_dir}/SHA256SUMS"
