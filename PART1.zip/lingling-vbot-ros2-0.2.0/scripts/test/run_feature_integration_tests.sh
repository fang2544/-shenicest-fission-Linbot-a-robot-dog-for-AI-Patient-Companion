#!/usr/bin/env bash
set -eo pipefail

workspace="${VBOT_WS:-/vbot_ws}"
install_prefix="${VBOT_INSTALL_PREFIX:-${workspace}/install}"
report_dir="${workspace}/reports"

source /opt/ros/humble/setup.bash
source "${install_prefix}/setup.bash"
set -u
mkdir -p "${report_dir}"

run_case() {
  local name="$1"
  local node_command="$2"
  local harness="$3"
  local log="${report_dir}/${name}_integration.log"

  setsid bash -lc "source /opt/ros/humble/setup.bash; source '${install_prefix}/setup.bash'; ${node_command}" \
    >"${log}" 2>&1 &
  local node_pid=$!

  local result=0
  python3 "${harness}" || result=$?

  kill -INT -- "-${node_pid}" 2>/dev/null || true
  for _ in $(seq 1 30); do
    kill -0 "${node_pid}" 2>/dev/null || break
    sleep 0.1
  done
  kill -TERM -- "-${node_pid}" 2>/dev/null || true
  wait "${node_pid}" 2>/dev/null || true

  if (( result != 0 )); then
    echo "失败：${name}；节点日志：${log}" >&2
    return "${result}"
  fi
  echo "通过：${name}"
}

run_case \
  wakeup_welcome \
  "ros2 launch wakeup_welcome wakeup_welcome.launch.py" \
  "${workspace}/src/wakeup_welcome/test/integration_harness.py"

run_case \
  lost_pause_reminder \
  "ros2 launch lost_pause_reminder lost_pause_reminder.launch.py" \
  "${workspace}/src/lost_pause_reminder/test/integration_harness.py"

VBOT_WS="${workspace}" VBOT_INSTALL_PREFIX="${install_prefix}" \
  bash "${workspace}/src/aed_emergency_response/test/run_integration.sh"
echo '通过：aed_emergency_response'
