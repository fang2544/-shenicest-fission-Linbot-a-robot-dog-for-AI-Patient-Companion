#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${repo_root}"
docker compose build vbot_sim
docker compose run --rm --service-ports vbot_sim bash -lc \
  'source /opt/ros/humble/setup.bash && cd /vbot_ws && colcon build --build-base build_sim --install-base install_sim --symlink-install && source install_sim/setup.bash && bash src/vbot_simulation/test/start_second_dev_browser_gui.sh'
