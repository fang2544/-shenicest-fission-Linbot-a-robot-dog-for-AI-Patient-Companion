#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${repo_root}"

forbidden="$(find . \
  \( -path './.git' -o -path './dist' -o -path './vbot_ws/build*' \
     -o -path './vbot_ws/install*' -o -path './vbot_ws/log*' \) -prune -o \
  \( -name '__pycache__' -o -name '*.pyc' -o -name '*.pyo' \
     -o -name '__MACOSX' -o -name '._*' -o -name '.DS_Store' \) \
  -print)"

if [[ -n "${forbidden}" ]]; then
  echo '仓库包含生成文件或操作系统元数据：' >&2
  echo "${forbidden}" >&2
  exit 1
fi

archive_failed=0
while IFS= read -r -d '' archive; do
  case "${archive}" in
    *.zip)
      listing="$(unzip -Z1 "${archive}")"
      ;;
    *.tar.gz|*.tgz)
      listing="$(tar -tzf "${archive}")"
      ;;
    *)
      continue
      ;;
  esac

  if grep -Eq '(^|/)(__MACOSX|__pycache__)(/|$)|(^|/)\._|\.py[co]$|(^|/)\.DS_Store$' <<<"${listing}"; then
    echo "压缩包包含禁止交付的元数据：${archive}" >&2
    archive_failed=1
  fi
done < <(find . \
  \( -path './.git' -o -path './dist' -o -path './vbot_ws/build*' \
     -o -path './vbot_ws/install*' -o -path './vbot_ws/log*' \) -prune -o -type f \
  \( -name '*.zip' -o -name '*.tar.gz' -o -name '*.tgz' \) -print0)

if (( archive_failed != 0 )); then
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
import ast
import xml.etree.ElementTree as ET

root = Path('vbot_ws/src')
packages = [
    'wakeup_welcome',
    'lost_pause_reminder',
    'hospital_escort_mvp',
    'aed_emergency_response',
    'restroom_priority_assistance',
    'vbot_simulation',
]

for package in packages:
    package_root = root / package
    manifest = ET.parse(package_root / 'package.xml').getroot()
    manifest_version = manifest.findtext('version')
    setup_source = (package_root / 'setup.py').read_text(encoding='utf-8')
    if f"version='{manifest_version}'" not in setup_source and \
            f'version="{manifest_version}"' not in setup_source:
        raise ValueError(f'{package}: package.xml and setup.py versions differ')
    for source in package_root.rglob('*.py'):
        ast.parse(source.read_text(encoding='utf-8'), filename=str(source))

ET.parse(root / 'vbot_simulation' / 'worlds' / 'hospital.world')
ET.parse(root / 'vbot_simulation' / 'urdf' / 'vbot_simple.urdf.xacro')

readme = Path('README.md').read_text(encoding='utf-8')
if readme.count('```mermaid') < 2:
    raise ValueError('README.md must contain architecture and call-chain diagrams')

print('已校验五个业务包、仿真包、Python 语法、XML 模型和 README 图表。')
PY

echo '仓库洁净检查通过。'
