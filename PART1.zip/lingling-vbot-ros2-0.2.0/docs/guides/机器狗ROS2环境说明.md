# VITA 机器狗 ROS 2 二次开发环境

## 已准备内容

- `vbot_ws/src/vbot_ros2_msgs`：VITA 官方公开 ROS 2 接口源码
- `Dockerfile`：Ubuntu 22.04 / ROS 2 Humble（ARM64）开发镜像
- `compose.yaml`：在 Apple Silicon Mac 上挂载工作区
- `scripts/build/build_vbot_ws.sh`：安装 ROS 依赖并用 colcon 编译全部接口包

## 当前安装状态

- Docker Desktop 4.88.1：已安装
- Docker Engine 29.7.2（Linux ARM64）：已运行
- Docker Compose 5.4.0：已安装
- Ubuntu 22.04 / ROS 2 Humble ARM64 镜像：已构建
- VITA ROS 2 接口：15 个包已编译并通过 Python 导入验证

以后使用前只需启动 Docker Desktop，等待 Docker Engine 正在运行。

## 构建

仅在修改 Dockerfile、依赖或需要重新编译接口时运行：

```bash
docker compose build
docker compose run --rm vbot_ros2 build_vbot_ws
```

## 进入开发环境

```bash
docker compose run --rm vbot_ros2 bash
source /vbot_ws/install/setup.bash
ros2 interface list | grep -E 'lowlevel_msg|function_msgs|vision_msgs'
```

验证当前环境：

```bash
docker compose run --rm vbot_ros2 bash -lc \
  'source /vbot_ws/install/setup.bash && ros2 pkg list | grep -E "function_msgs|slam_msgs|lowlevel_msg"'
```

自己的 ROS 2 功能包放到 `vbot_ws/src/` 下，再执行 `colcon build --symlink-install`。

## 与实体机器狗通信前的注意事项

此仓库只包含消息、服务和动作的“接口定义”，不包含机器狗底层驱动、IP 配置、
控制示例或厂商私有运行栈。需要向 VITA Dynamics 获取对应机型的通信文档、机器人
端 ROS_DOMAIN_ID、网络地址、Topic/Service/Action 名称以及安全控制流程。

Docker Desktop 的虚拟网络可能影响 ROS 2 DDS 的局域网发现。编译和代码开发可在
Mac 容器内完成；连接实体机器狗时，优先使用原生 Ubuntu 22.04 ARM64/AMD64 电脑，
或者根据机器狗的 DDS 配置使用已知节点地址和匹配的中间件配置。
