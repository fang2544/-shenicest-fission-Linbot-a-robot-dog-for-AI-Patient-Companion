# VBot Gazebo / Nav2 仿真说明

## 验证范围

该环境使用公开尺寸建立简化 VBot 平面运动模型，模拟 360° 激光雷达、IMU、深度相机，
并连接 SLAM Toolbox、AMCL 与 Nav2。它验证建图、定位、路径规划、局部避障、
`/cmd_vel -> /vel_cmd` 和公开 VBot `GoalNav` / SLAM 接口适配，不验证真实四足步态、
关节力矩、传感器标定、Zenoh 网络或厂商闭源算法。

ROS 2 Humble 的 Gazebo Classic 二进制包没有 Jammy ARM64 版本，因此保留原生 ARM64
开发镜像，并新增 `vbot_sim` amd64 仿真镜像。Docker Desktop 在 Apple Silicon 上通过
Rosetta 模拟运行该镜像；无头模式用于自动验收。

## 一键自动验收

```bash
chmod +x scripts/acceptance/运行VBot仿真.sh
./scripts/acceptance/运行VBot仿真.sh
```

脚本执行两个阶段：

1. 启动医院 Gazebo 世界和 SLAM Toolbox，以确定性遥控轨迹完成建图并保存地图。
2. 重新启动 Gazebo、AMCL 和 Nav2，加入横穿走廊的动态障碍物，通过 VBot `GoalNav`
   Action 导航到目标点并检查传感器、规划、避障及 `/vel_cmd` 链路。

主要报告：

- `/vbot_ws/reports/simulation_acceptance_summary.json`
- `/vbot_ws/reports/mapping_acceptance.json`
- `/vbot_ws/reports/navigation_acceptance.json`
- `/vbot_ws/maps/hospital_sim.yaml`
- `/vbot_ws/maps/hospital_sim.pgm`

## 手动建图

```bash
docker compose run --rm vbot_sim bash
source /opt/ros/humble/setup.bash
source /vbot_ws/install_sim/setup.bash
ros2 launch vbot_simulation mapping.launch.py gui:=false
```

另开一个容器终端执行键盘遥控：

```bash
docker compose run --rm vbot_sim bash
source /opt/ros/humble/setup.bash
source /vbot_ws/install_sim/setup.bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

保存地图：

```bash
ros2 service call /lightning/save_map slam_msgs/srv/SaveMap "{map_id: hospital_sim}"
```

## 导航与图形界面

无头导航：

```bash
ros2 launch vbot_simulation navigation.launch.py gui:=false
```

推荐的浏览器图形界面（无需 XQuartz）：

```bash
chmod +x scripts/launch/启动VBot图形仿真.sh
./scripts/launch/启动VBot图形仿真.sh
```

然后打开 `http://localhost:6080/vnc.html?autoconnect=true`。页面内同时显示 Gazebo 和
RViz。Docker Desktop 的 amd64 软件渲染速度会明显慢于原生 Ubuntu。

## 陪诊流程接入真实 Nav2

`cardiology_nav.launch.py` 不再使用 `mock_vbot` 返回导航成功，而是通过：

`hospital_escort_mvp -> GoalNav -> NavigateToPose -> /cmd_vel -> /vel_cmd -> Gazebo`

执行每个检查点。运行：

```bash
bash /vbot_ws/src/vbot_simulation/test/run_cardiology_nav2_acceptance.sh
```

完成后查看陪诊业务链验收报告：

`/vbot_ws/reports/cardiology_nav2_dialogue.json`
