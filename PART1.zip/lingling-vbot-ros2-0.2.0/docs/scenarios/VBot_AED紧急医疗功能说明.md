# VBot 统一急救模式功能说明

## 已实现的链路

1. 接收 VBot `/asr/result`，识别心脏骤停、严重出血、严重过敏、低血糖或综合急救物资请求，并解析医院地点。
2. 对“只问 AED 在哪里”、低置信度、ASR reject 及“只是演练/不需要 AED”等语句不触发导航。
3. 紧急请求先向 VBot `/goal_nav` 发送 `control=false` 抢占当前任务，再发送目的地。
4. `GoalNav` 兼容桥把请求接入真正的 Nav2 `NavigateToPose` Action，Gazebo 中经 AMCL 定位后移动。
5. 到达后通过 `/speech/SpeechTextData` 播放对应场景的 3～7 段急救指导；状态发布到
   `/aed_emergency/status`，可视化发布到 `/aed_emergency/markers`。
6. 简化 VBot URDF 背部增加 AED 箱和密封急救药品/敷料箱，RViz 同时显示地图、机器人、
   LiDAR、Nav2 路径、红色急救目标和当前状态。

示例语音：`心电图室有人倒地不醒没有正常呼吸，马上送 AED 来急救`。

统一背负物资包括 AED、手套、呼吸膜、止血敷料、无菌纱布、弹性绷带、
血糖仪，以及受控的肾上腺素自动注射器和葡萄糖凝胶封存盒。机器人不自动给药，
药品只交由有资质医护人员、患者本人或受过训练者按医嘱和产品标签使用。

## 一键验收

```bash
./scripts/acceptance/运行AED紧急医疗验收.sh
```

该命令执行两层测试：

- 快速接口集成测试：验证心脏骤停与严重出血两类意图、两轮任务抢占、GoalNav 和 15 次 TTS。
- Gazebo 端到端测试：验证 Gazebo 物理模型、AMCL、真实 Nav2 Action、到达误差、
  七步指导和最终状态，并生成：
  - `vbot_ws/reports/aed_emergency_acceptance.json`
  - `vbot_ws/reports/aed_emergency_visual_report.html`

## 可视化演示

```bash
./scripts/launch/启动AED紧急医疗可视化.sh
```

启动后浏览器打开：

- Gazebo + RViz：<http://localhost:6080/vnc.html?autoconnect=true>
- 实时验收页：<http://localhost:6081/aed_emergency_visual_report.html>

演示会初始化 AMCL 位姿，45 秒后自动注入心电图室 AED 请求。Gazebo/RViz 在 amd64
兼容层下启动较慢，首次出现画面通常需要约 1 分钟。

## 医疗与工程边界

本功能只验证语音意图、机器人导航、消息兼容和指导语播报，不是医疗器械，不做心律
诊断，也不能决定是否电击。真实紧急情况必须立即启动院内急救响应并拨打 120；是否
电击只以合规 AED 设备的分析和语音提示为准。真实部署还必须完成：

- 医院急救团队审核话术和处置流程；
- 真机负载、制动、跌落、续航、无线覆盖和电梯/门禁测试；
- 真实 ASR、扬声器、定位精度、拥挤人群避障和任务优先级验证；
- AED 固定与快速取用机构、医疗器械合规和定期巡检。

指导语依据美国心脏协会公开急救流程整理，项目配置中保持“拨打 120”的中国本地化。
