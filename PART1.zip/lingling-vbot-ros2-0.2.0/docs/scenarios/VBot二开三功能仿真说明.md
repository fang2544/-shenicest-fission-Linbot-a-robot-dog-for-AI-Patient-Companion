# VBot 二开三功能联合仿真

## 已整理的三个 ROS 2 功能包

1. `wakeup_welcome`：收到 VBot `WakeupInfo` 后播放欢迎表情并请求 TTS。
2. `lost_pause_reminder`：UWB 距离超限后防抖暂停跟随、停止导航并语音提醒；距离恢复后继续跟随。
3. `hospital_escort_mvp`：医院 2.5D 图导航、心内科多检查点陪诊和真实 Nav2 Action 链路。

公开 VBot 消息接口包位于 `vbot_ws/src/vbot_ros2_msgs`，仿真编排、模拟外设和可视化位于
`vbot_ws/src/vbot_simulation`。

## 一键自动验收

```bash
cd "/Users/hanwanyin/Documents/ChatGPT/New project"
./scripts/acceptance/运行三个二开功能验收.sh
```

脚本会在同一个 Gazebo/Nav2 ROS 图中自动执行：

1. 发布唤醒事件，验证欢迎表情和 TTS 请求。
2. 模拟 UWB 距离从 `4.2 m` 恢复到 `2.0 m`，验证暂停、提醒、GoalNav 停止和恢复。
3. 初始化 AMCL，执行抽血、心电图、彩超候诊、心脏彩超和返回心内科的完整 Nav2 路线。

联合验收使用静态医院路线，避免 amd64 软件仿真实时率波动影响业务回归的可重复性。
动态障碍避障由 `simulation_acceptance_summary.json` 中的 Nav2 专项验收单独覆盖。

验收产物：

- `vbot_ws/reports/second_dev_acceptance.json`
- `vbot_ws/reports/second_dev_visual_report.html`
- `vbot_ws/reports/second_dev_launch.log`
- `vbot_ws/reports/wakeup_welcome_test.log`
- `vbot_ws/reports/lost_pause_reminder_test.log`

## Gazebo / RViz / 浏览器可视化

```bash
./scripts/launch/启动三个二开功能可视化.sh
```

打开：

- Gazebo + RViz：`http://localhost:6080/vnc.html?autoconnect=true`
- 实时验收看板：`http://localhost:6081/second_dev_visual_report.html`
- 当前图形会话：`http://localhost:6081/second_dev_gui_live.html`

图形模式会自动初始化 AMCL，但不会自动重跑整条陪诊路线，以避免 Apple Silicon
上 amd64 Gazebo GUI 软件渲染对 Nav2 时序的影响。完整路线结果以上一节的无头自动验收为准。

RViz 已预配置下列图层：

- 医院占据地图 `/map`
- VBot 机器人模型和 LiDAR `/scan`
- Nav2 全局路径 `/plan`
- 五个医院检查点和三功能状态 `/second_dev/markers`

可机器读的实时状态在 `/second_dev/status`，业务事件在 `/second_dev/events`。

## 仿真边界

语音、表情、UWB 和跟随服务在模拟机中由确定性外设节点代替；导航使用真实
AMCL/Nav2/Gazebo 链路。真机上仍需复验麦克风唤醒、扬声器、脸屏表情、UWB 标定、
Zenoh 传输、四足步态和安全停车响应。
