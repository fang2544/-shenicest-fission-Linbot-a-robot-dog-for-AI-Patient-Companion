# VITA 医院陪诊 MVP：接口测试与差距评估

## 结论

当前已经完成一个可编译、可自动测试、可模拟运行的 ROS 2 Humble 单楼层陪诊软件骨架。
它证明公开接口足以支撑“固定 POI + 语音 + 高层导航 + 失败停止”的业务编排。

它还不能证明实体机器狗能够完成陪诊。当前未连接机器狗，因此厂商节点名称、DDS/QoS、
真实导航、定位、避障、语音、跟随和物理安全行为仍未验证。

## 已实现代码

- `mock_vbot`：模拟 GoalNav、跟随、语音、SLAM、地图和传感器接口。
- `capability_probe`：按 ROS 类型自动探测 Topic、Service、Action 并生成 JSON 报告。
- `VitaInterfaceClient`：封装导航、语音、跟随/陪伴和停止请求。
- `escort_demo`：六站单楼层陪诊流程、错误处理和 JSONL 审计日志。
- `hospital_F1.yaml`：门诊大厅、挂号窗口、诊室、检验科、药房和出口 POI。
- 5 个自动化测试：POI 配置、导航契约、跟随常量和关键接口导入。

## 测试结果

| 测试 | 结果 | 能证明什么 |
|---|---:|---|
| ROS 2 Humble 编译 | PASS | 新包能在 Ubuntu 22.04 ARM64 中构建 |
| pytest | 5/5 PASS | 配置和公开接口字段符合代码预期 |
| 模拟 ROS graph | 16/16 PASS | 探测器能识别所需接口类型 |
| 六站陪诊成功路径 | PASS | 语音、Action反馈、逐站导航和日志链路跑通 |
| 导航失败注入 | PASS | 首站失败后停止任务、播报并请求人工介入 |
| 无模拟器/无真机探测 | 0/16 FOUND | 当前没有连接或发现实体机器狗节点 |

模拟报告：`vbot_ws/reports/vbot_capability_report.json`

无真机报告：`vbot_ws/reports/no_robot_capability_report.json`

流程日志：`vbot_ws/reports/escort_demo.jsonl`

## 现在可以做的

1. 在 Docker 中持续开发和测试 ROS 2 业务节点。
2. 使用模拟器演示固定路线、语音、导航反馈、成功和失败流程。
3. 修改 POI YAML 建立单楼层路线。
4. 连接真机后直接运行能力探测器，获取真实接口名称。
5. 通过 ROS 参数适配厂商实际的 GoalNav、ControlFollowing 和 SetSpeak 名称。
6. 记录每个任务阶段和导航结果，支持后续后台接入。

## 目前不能确认或不能完成的

1. 不能确认真机是否运行这些 Service/Action，也不能确认真实名称与模拟名称一致。
2. 不能确认 Docker Desktop 能否通过 DDS 多播发现机器狗。
3. 不能确认坐标系、单位、地图原点、QoS、ROS_DOMAIN_ID 和 DDS 实现。
4. 不能证明真实导航成功率、到达误差、避障距离或拥挤人群表现。
5. 不能证明 `ACCOMPANY` 的实际行为，也没有指定患者注册、ReID 或掉队检测接口。
6. 不能实现电梯、跨楼层、HIS、叫号、缴费或取药系统闭环。
7. 目前没有工作人员网页、二维码绑定和人工继续/暂停界面。
8. 当前停止逻辑是业务级软停止，不能替代本体 watchdog、碰撞保护和硬件急停。
9. 不能根据 `GoalNav.z` 推断机器狗支持三维地形或楼梯规划。

## 距离 MVP 的量化估计

以下是“可在真实医院单楼层低速演示”的加权工程估计，不是产品安全认证进度：

| 工作项 | 权重 | 当前完成度 | 加权贡献 |
|---|---:|---:|---:|
| ROS 环境和公开接口契约 | 10% | 100% | 10% |
| 模拟器和适配层 | 15% | 80% | 12% |
| 陪诊状态机与任务日志 | 15% | 60% | 9% |
| 真机接口和 DDS 联调 | 15% | 0% | 0% |
| 真机地图、定位、导航和避障 | 20% | 0% | 0% |
| 患者绑定与掉队检测 | 10% | 0% | 0% |
| 二维码、工作人员后台和人工控制 | 5% | 0% | 0% |
| 安全测试和医院现场验收 | 10% | 0% | 0% |
| **合计** | **100%** |  | **约 31%** |

因此：

- 离“Docker 中的软件模拟演示”约完成 65%–70%。
- 离“真机单楼层陪诊 MVP”约完成 30%，仍有约 70% 工作依赖真机和医院现场。
- 离“可以在医院无人值守运行的产品”仍很远，当前不应按产品安全等级使用。

如果厂商高层导航、语音、定位和失联停车已经成熟，拿到真机与网络文档后，基础真机
原型通常还需要约 2–4 周的软件联调与现场测试。如果需要自研患者跟踪、导航或安全
控制，周期可能扩大到 6–12 周以上。该时间估计不包含医院审批、隐私合规和产品认证。

## 下一步真机测试顺序

1. 用网线或厂商指定 Wi-Fi 连接机器狗。
2. 确认机器人 IP、ROS_DOMAIN_ID、Fast DDS/Cyclone DDS 和网络发现方式。
3. 运行无模拟器能力探测，保存真实 ROS graph。
4. 先调用 `pre_check=true` 的高层接口，不发送运动命令。
5. 在架空或安全围栏环境验证停止、语音和 Action 取消。
6. 低速验证单点导航，再测六个 POI；不直接使用 LowCmd/MotorCmd。
7. 测量成功率、到达误差、断网停车、定位丢失停车和患者掉队响应。
8. 真机能力通过后再开发二维码后台、人工控制和患者掉队检测。

## 常用命令

```bash
cd "/Users/hanwanyin/Documents/ChatGPT/New project"
docker compose run --rm vbot_ros2 bash
source /vbot_ws/install/setup.bash
```

模拟成功路线：

```bash
ros2 launch hospital_escort_mvp mock_mvp.launch.py
```

模拟导航失败：

```bash
ros2 launch hospital_escort_mvp mock_mvp.launch.py fail_navigation:=true
```

连接真机后探测：

```bash
ros2 run hospital_escort_mvp capability_probe \
  --ros-args \
  -p discovery_seconds:=10.0 \
  -p report_path:=/vbot_ws/reports/real_robot_capability_report.json
```
