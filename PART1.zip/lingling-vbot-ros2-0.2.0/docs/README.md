# 项目文档目录

根目录 `README.md` 是项目的统一入口。这里仅保存需要深入阅读的专题资料。

## 架构与评估

- [3D 建图与路径规划](architecture/3D建图与路径规划交付说明.md)
- [多楼层二维导航](architecture/多楼层二维导航交付说明.md)
- [VITA 接口测试与差距评估](architecture/MVP接口测试与差距评估.md)

## 环境与操作指南

- [ROS 2 二次开发环境](guides/机器狗ROS2环境说明.md)
- [Gazebo 与 Nav2 仿真](guides/VBot_Gazebo仿真说明.md)
- [展厅演示与真实建图](guides/展厅演示与真实建图说明.md)

## 业务场景

- [五个功能包与交互轮次](scenarios/聆灵五功能包与交互轮次说明.md)
- [4×3 米展厅语音脚本](scenarios/4x3米展厅语音交互脚本.md)
- [心内科检查陪诊](scenarios/心内科检查陪诊演示说明.md)
- [医院院区接客调度](scenarios/医院院区接客调度说明.md)
- [统一急救模式](scenarios/VBot_AED紧急医疗功能说明.md)
- [二次开发功能联合仿真](scenarios/VBot二开三功能仿真说明.md)

专题文档用于说明设计依据、验收场景和操作细节。项目定位、整体架构、模块关系、构建方式和发布方法以根目录 `README.md` 为准。
